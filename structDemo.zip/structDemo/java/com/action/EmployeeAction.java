package com.action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.listener.HibernateListener;
import com.pojo.Employee;

public class EmployeeAction {
	private int eno;

	private String ename;

	private double esal;

	private String eaddr;
	
	Employee e=new Employee();

	public int getEno() {
		return eno;
	}

	public void setEno(int eno) {
		this.eno = eno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getEsal() {
		return esal;
	}

	public void setEsal(double esal) {
		this.esal = esal;
	}

	public String getEaddr() {
		return eaddr;
	}

	public void setEaddr(String eaddr) {
		this.eaddr = eaddr;
	}

	public String execute()
	{
		SessionFactory sessionFactory = (SessionFactory) ServletActionContext.getServletContext()
				.getAttribute(HibernateListener.KEY_NAME);

		Session session = sessionFactory.openSession();
		HttpServletRequest request = ServletActionContext.getRequest();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
		request.setAttribute("message", "inserted successfully");
		
		return "success";
	}

	

}
